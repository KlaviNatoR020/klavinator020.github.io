gdjs.New_32sceneCode = {};
gdjs.New_32sceneCode.GDButton_95OppenObjects1= [];
gdjs.New_32sceneCode.GDButton_95OppenObjects2= [];
gdjs.New_32sceneCode.GDNewObject2Objects1= [];
gdjs.New_32sceneCode.GDNewObject2Objects2= [];
gdjs.New_32sceneCode.GDChestObjects1= [];
gdjs.New_32sceneCode.GDChestObjects2= [];
gdjs.New_32sceneCode.GDCardsObjects1= [];
gdjs.New_32sceneCode.GDCardsObjects2= [];
gdjs.New_32sceneCode.GDNewObject4Objects1= [];
gdjs.New_32sceneCode.GDNewObject4Objects2= [];

gdjs.New_32sceneCode.conditionTrue_0 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_0 = {val:false};
gdjs.New_32sceneCode.conditionTrue_1 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_1 = {val:false};


gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDButton_9595OppenObjects1Objects = Hashtable.newFrom({"Button_Oppen": gdjs.New_32sceneCode.GDButton_95OppenObjects1});gdjs.New_32sceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition0IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8069212);
}
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.New_32sceneCode.GDNewObject4Objects1);
{runtimeScene.getGame().getVariables().get("Бэбрик").add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.New_32sceneCode.GDNewObject4Objects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNewObject4Objects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}}

}


};gdjs.New_32sceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Oppen"), gdjs.New_32sceneCode.GDButton_95OppenObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
gdjs.New_32sceneCode.condition2IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDButton_9595OppenObjects1Objects, runtimeScene, false, false);
}if ( gdjs.New_32sceneCode.condition1IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition2IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.6, "Открытие");
}}
}
if (gdjs.New_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cards"), gdjs.New_32sceneCode.GDCardsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Chest"), gdjs.New_32sceneCode.GDChestObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDChestObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDChestObjects1[i].setAnimationFrame(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.random(4));
}{for(var i = 0, len = gdjs.New_32sceneCode.GDCardsObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCardsObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Открытие");
}{for(var i = 0, len = gdjs.New_32sceneCode.GDCardsObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCardsObjects1[i].setAnimationFrame(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "Открытие");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cards"), gdjs.New_32sceneCode.GDCardsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Chest"), gdjs.New_32sceneCode.GDChestObjects1);
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "Открыть");
}{for(var i = 0, len = gdjs.New_32sceneCode.GDChestObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDChestObjects1[i].setAnimationFrame(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDCardsObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCardsObjects1[i].hide();
}
}
{ //Subevents
gdjs.New_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cards"), gdjs.New_32sceneCode.GDCardsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Chest"), gdjs.New_32sceneCode.GDChestObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewObject4"), gdjs.New_32sceneCode.GDNewObject4Objects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDChestObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDChestObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDCardsObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCardsObjects1[i].pauseAnimation();
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.random(4));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Date", "Money", runtimeScene, runtimeScene.getVariables().getFromIndex(0));
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)));
}{for(var i = 0, len = gdjs.New_32sceneCode.GDNewObject4Objects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNewObject4Objects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("Date", "Money", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}}

}


};

gdjs.New_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.New_32sceneCode.GDButton_95OppenObjects1.length = 0;
gdjs.New_32sceneCode.GDButton_95OppenObjects2.length = 0;
gdjs.New_32sceneCode.GDNewObject2Objects1.length = 0;
gdjs.New_32sceneCode.GDNewObject2Objects2.length = 0;
gdjs.New_32sceneCode.GDChestObjects1.length = 0;
gdjs.New_32sceneCode.GDChestObjects2.length = 0;
gdjs.New_32sceneCode.GDCardsObjects1.length = 0;
gdjs.New_32sceneCode.GDCardsObjects2.length = 0;
gdjs.New_32sceneCode.GDNewObject4Objects1.length = 0;
gdjs.New_32sceneCode.GDNewObject4Objects2.length = 0;

gdjs.New_32sceneCode.eventsList1(runtimeScene);
return;

}

gdjs['New_32sceneCode'] = gdjs.New_32sceneCode;
